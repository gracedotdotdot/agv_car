#include "ros/ros.h"
#include "Human_follow.h"
#include "std_msgs/String.h"
#include <serial/serial.h>
#include <sstream>
#include <std_msgs/UInt8MultiArray.h>
#include <std_msgs/UInt32MultiArray.h>
#include <iostream>
#include <string>
#include <cmath>
#include <numeric>
#include <geometry_msgs/Twist.h>
Ultra_Box UltraBox;
AOA_Box _AOA_Box;
UWB_Box _UWB_Box;
//Argument Setting
//int Long_Dist = 60;
//int Short_Dist = 40;
/*************************************/ 
double v = First_v;		//cm
double w = First_w;		//rad
//UWB AP Distance
int A2_A0 = 45;
int A2_A1 = 45;
int A2_A3 = 50;
//Sensor Value
unsigned int UWB_Val[3]={0};
unsigned int Ultra_Val[3]={0};
int Encode_Vals[4]={0};
int AOA_Val[2]={0};
void Encode_callback(const std_msgs::UInt8MultiArray::ConstPtr& array)
{
	int index = 0;
	for(std::vector<unsigned char>::const_iterator it = array->data.begin(); it != array->data.end(); ++it)
	{
		Encode_Vals[index++] = (int)*it;
		//cout << UWB_Val[index-1] << " " << endl;
	}
}
double Angle(float LengthA,float LengthB,float LengthC)
{
	//cout << LengthA << "," << LengthB << "," << LengthC<< "," << (LengthB*LengthB+LengthA*LengthA-LengthC*LengthC)/(2.0*LengthA*LengthB);
	//cout << "," << LengthC-LengthA << endl;
	return (LengthB*LengthB+LengthA*LengthA-LengthC*LengthC)/(2.0*LengthA*LengthB);
	//return ((LengthB*LengthB)+(LengthC*LengthC)-(LengthA*LengthA))/(2*LengthB*LengthC);
}
void UWB_callback(const std_msgs::UInt32MultiArray::ConstPtr& array)
{
	int index = 0;
	// print all the remaining numbers
	for(std::vector<unsigned int>::const_iterator it = array->data.begin(); it != array->data.end(); ++it)
	{
		UWB_Val[index++] = *it;
		//cout << UWB_Val[index-1] << " " << endl;
	}
	_UWB_Box.Put_value(UWB_Val[2],UWB_Val[0],UWB_Val[1]);
	_UWB_Box.UWB_Mean_func();
	//cout << _UWB_Box.UWB_Mean[0] << "," << _UWB_Box.UWB_Mean[1] << "," << _UWB_Box.UWB_Mean[2] << endl;
	//float Angle1 = Angle((float)UWB_Val[1],300.0,(float)UWB_Val[0]);
	//float Angle2 = Angle((float)UWB_Val[0],220.0,(float)UWB_Val[2]);	
	//cout << Angle1 << endl;
	//cout << Angle2 << endl;
	//cout << endl;
	return;
}
void Ultra_callback(const std_msgs::UInt32MultiArray::ConstPtr& array)
{
	int index = 0;
	// print all the remaining numbers
	for(std::vector<unsigned int>::const_iterator it = array->data.begin(); it != array->data.end(); ++it)
	{
		Ultra_Val[index++] =  *it;
		//cout << Ultra_Val[index-1] << " " << endl;
	}

	UltraBox.Put_value(Ultra_Val[0],Ultra_Val[1],Ultra_Val[2]);
	UltraBox.UltraBox_Mean_func();
    //cout << UltraBox.UltraBox_Mean[0] << "," << UltraBox.UltraBox_Mean[1] << ","<< UltraBox.UltraBox_Mean[2] << endl;
	return;
}
void AOA_callback(const std_msgs::UInt32MultiArray::ConstPtr& array)
{
	int index = 0;
	// print all the remaining numbers
	for(std::vector<unsigned int>::const_iterator it = array->data.begin(); it != array->data.end(); ++it)
	{
		AOA_Val[index] = (int)*it;
		index++;
	}
	AOA_Val[0] -=135;
	//AOA_Val[0] -= 135;
	//Calibration
	_AOA_Box.Put_value(AOA_Val[0],AOA_Val[1]);
	_AOA_Box.AOABox_Mean_func();
	//cout << _AOA_Box.AOABOX_Mean << endl;
	return;
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "Human_follow");
	ros::NodeHandle nh;
	ros::Subscriber UWB_node = nh.subscribe("Serial_UWB_node", 100,UWB_callback);
	ros::Subscriber Ultra_node = nh.subscribe("serial_Ultrasonic_node", 10,Ultra_callback);
	ros::Subscriber AOA_node = nh.subscribe("Serial_AOA_node", 10,AOA_callback);
	ros::Subscriber Encode_Val = nh.subscribe("Encode_val", 10,Encode_callback);
	//Car move control
	ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("cmd_vel", 1000);
	ros::Rate loop_rate(100);
	//
	int Decrease_flag = 0;
	Move_Control MCL;
	while (ros::ok())
    {
		geometry_msgs::Twist cmd;
		cmd.linear.x = MCL.v;
		//cmd.angular.z = MCL.w;
		cmd.angular.z = MCL.w;
		MCL.Updata(UWB_Val,Ultra_Val,AOA_Val);
		MCL.Control();
		cout << "Current Speed(R):" <<  Encode_Vals[0] << " Current Speed(L):" << Encode_Vals[2] << ",Ultrasonic_Dist:" << Ultra_Val[0] << "," << Ultra_Val[1]<< "," << Ultra_Val[2];
		cout << ",AOA_Dist:" << AOA_Val[1] <<",Dream Speed:"<< MCL.v <<", Dream Angle:" << MCL.w << endl;
		//Avoid(1);
		/*
		cout << "Current Distance: " << UltraBox.UltraBox_Mean[1] << ",Current Speed: " << v << endl;
		//
		if((UltraBox.UltraBox_Mean[0]*UltraBox.UltraBox_Mean[1]*UltraBox.UltraBox_Mean[2])>0)
		{
			if(UltraBox.UltraBox_Mean[1]<Short_Dist)
			{
				v = 0;
				w = 0;
			}
			else if(UltraBox.UltraBox_Mean[1]<Long_Dist)
			{
				Decrease_flag = 0; 
				v = v - De_in_crease_Speed;
				if(v<=0) v=0;
				//cout << "Current Distance:" << UltraBox.UltraBox_Mean[1] << endl;
				//cout << "Current Speed:" << v << endl;
			}
			else if(UltraBox.UltraBox_Mean[1]>=50 && Decrease_flag == 0)
			{
				v = v + De_in_crease_Speed;
				if(v >= First_v)
				{
					v = First_v;
					Decrease_flag == 1;
				}
			}
		}
		*/
		pub.publish(cmd);
		//UltraBox.UltraBox_Mean[0];
		//UltraBox.UltraBox_Mean[1];
		//UltraBox.UltraBox_Mean[2];
		// ros::Duration(0.1).sleep();
        ros::spinOnce();
		loop_rate.sleep();
    }
    return 0;
}